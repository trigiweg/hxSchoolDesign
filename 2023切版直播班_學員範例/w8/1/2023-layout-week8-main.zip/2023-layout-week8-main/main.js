import './assets/scss/all.scss';
import './assets/js/swiper';
import 'bootstrap/dist/js/bootstrap.min.js';

console.log("Hello world!");