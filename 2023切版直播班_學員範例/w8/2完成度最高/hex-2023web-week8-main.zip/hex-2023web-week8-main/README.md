# AI 虛擬陪伴 - ALPHABOX+

* [AI 虛擬陪伴 - ALPHABOX+](https://tami1118.github.io/hex-2023web-week8/)
* [元件測試頁](https://tami1118.github.io/hex-2023web-week8/test.html)